package br.edu.iffarroupilha.sigachat.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import br.edu.iffarroupilha.sigachat.modelos.Grupo;
import br.edu.iffarroupilha.sigachat.modelos.Preferencias;
import br.edu.iffarroupilha.sigachat.modelos.dto.GrupoDTO;
import br.edu.iffarroupilha.sigachat.modelos.dto.PreferenciasDTO;
import br.edu.iffarroupilha.sigachat.services.PreferenciasService;

import java.util.List;

/**
 * <p>
 * Controle para delegar as ações para a entidade Preferencias
 * </p>
 * 
 * @author Professor
 * @since Nov 6, 2024 8:24:36 PM
 */
@RestController
@RequestMapping("/preferencias")
public class PreferenciasControle {

    @Autowired
    private PreferenciasService servico;

    @PostMapping
    public ResponseEntity<Preferencias> gravar( @RequestBody PreferenciasDTO dto) {
        Preferencias p = new Preferencias(dto);
        return ResponseEntity.
        		status(HttpStatus.CREATED).
        		body( this.servico.gravar(p));
    }


    @PutMapping
    public ResponseEntity atualizar(@RequestBody PreferenciasDTO dto) {
        Preferencias pAtualizada = new Preferencias(dto);
        Preferencias atualizada = servico.gravar(pAtualizada);
        return ResponseEntity.ok(atualizada);
    }

   
    @GetMapping
	public ResponseEntity listarDados() {
		return ResponseEntity.ok( this.servico.listar());
		
	}
    
	@DeleteMapping
	public ResponseEntity deletar(@RequestBody PreferenciasDTO dto) {
		Preferencias deletar = new Preferencias(dto);
		
		this.servico.apagar(deletar);
		return ResponseEntity.ok("item excluido");
		
	}
}
