package br.edu.iffarroupilha.sigachat.modelos;
/**
 * <p>
 * Interface de marcação para determinar de dada classe 
 * é uma entidade
* </p>
* @author Professor
* @since Nov 6, 2024 7:49:04 PM
*/

public interface IEntidade {

}
