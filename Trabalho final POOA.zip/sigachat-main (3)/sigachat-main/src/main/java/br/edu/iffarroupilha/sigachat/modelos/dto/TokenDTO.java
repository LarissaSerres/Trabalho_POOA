package br.edu.iffarroupilha.sigachat.modelos.dto;
/**
 * <p>
 * encapsular um token para facilitar e padronizar a saida
* </p>
* @author Professor
* @since Jan 10, 2025 7:28:21 PM
*/

public record TokenDTO (String token) {

}
