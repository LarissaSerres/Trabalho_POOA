package br.edu.iffarroupilha.sigachat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SigachatApplicationTests {

	@Test
	void contextLoads() {
	}

}
